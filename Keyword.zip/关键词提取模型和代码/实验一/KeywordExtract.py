﻿# -*- coding: utf-8 -*-
import math
import jieba
import jieba.posseg as psg
from gensim import corpora, models
from jieba import analyse
import functools
import os
import numpy as np
import gensim.models as g

# 停用词表加载方法
def get_stopword_list():
    # 停用词表存储路径，每一行为一个词，按行读取进行加载
    # 进行编码转换确保匹配准确率
    stop_word_path = './stopword.txt'
    stopword_list = [sw.replace('\n', '') for sw in open(stop_word_path,encoding="utf-8").readlines()]
    return stopword_list

# 分词方法，调用结巴接口
def seg_to_list(sentence, pos=False):
    if not pos:
        # 不进行词性标注的分词方法
        seg_list = jieba.cut(sentence)
    else:
        # 进行词性标注的分词方法
        seg_list = psg.cut(sentence)
    return seg_list

# 去除干扰词
def word_filter(seg_list, pos=False):
    stopword_list = get_stopword_list()
    filter_list = []
    # 根据POS参数选择是否词性过滤
    ## 不进行词性过滤，则将词性都标记为n，表示全部保留
    for seg in seg_list:
        if not pos:
            word = seg
            flag = 'n'
        else:
            word = seg.word
            flag = seg.flag
        if not flag.startswith('n'):
            continue
        # 过滤停用词表中的词，以及长度为<2的词
        if not word in stopword_list and len(word) > 1:
            filter_list.append(word)
    return filter_list

# 数据加载，pos为是否词性标注的参数，corpus_path为数据集路径
def load_data(word_list,pos=False):
    # 调用上面方式对数据集进行处理，处理后的每条数据仅保留非干扰词
    content = word_list.strip()
    seg_list = seg_to_list(content, pos)
    filter_list = word_filter(seg_list, pos)
    return filter_list

# idf值统计方法
def train_idf(doc_list):
    idf_dic = {}
    # 总文档数
    tt_count = len(doc_list)

    # 每个词出现的文档数
    for doc in doc_list:
        for word in set(doc):
            idf_dic[word] = idf_dic.get(word, 0.0) + 1.0

    # 按公式转换为idf值，分母加1进行平滑处理
    for k, v in idf_dic.items():
        idf_dic[k] = math.log(tt_count / (1.0 + v))

    # 对于没有在字典中的词，默认其仅在一个文档出现，得到默认idf值
    default_idf = math.log(tt_count / (1.0))
    return idf_dic, default_idf

#  排序函数，用于topK关键词的按值排序
def cmp(e1, e2):
    import numpy as np
    res = np.sign(e1[1] - e2[1])
    if res != 0:
        return res
    else:
        a = e1[0] + e2[0]
        b = e2[0] + e1[0]
        if a > b:
            return 1
        elif a == b:
            return 0
        else:
            return -1

# TF-IDF类
class TfIdf(object):
    # 四个参数分别是：训练好的idf字典，处理后的待提取文本，关键词数量
    def __init__(self,idf_dic, default_idf, word_list,keyword_num):
        self.word_list = word_list
        self.idf_dic, self.default_idf = idf_dic, default_idf
        self.keyword_num = keyword_num

    # 统计tf值
    def get_tf_dic(self,doc):
        tf_dic = {}
        for word in doc:   #某个单词在一个文档中出现的次数
            tf_dic[word] = tf_dic.get(word, 0.0) + 1.0
        for word in set(doc):
            tf_dic[word]=tf_dic.get(word)/len(doc)   #词频
        return tf_dic

    # 按公式计算tf-idf
    def get_tfidf(self):
        for doc in self.word_list:
            tfidf_dic = {}
            tf_dic=self.get_tf_dic(doc)
            for seg in doc:
                idf = self.idf_dic.get(seg, self.default_idf)
                tf = tf_dic.get(seg, 0)
                tfidf=idf*tf
                tfidf_dic[seg] = tfidf
            # 根据tf-idf排序，去排名前keyword_num的词作为关键词
            for k, v in sorted(tfidf_dic.items(), key=functools.cmp_to_key(cmp), reverse=True)[:self.keyword_num]:
                file_number.write(k+' ')
            file_number.write('\n')

# 主题模型
class TopicModel(object):
    # 三个传入参数：处理后的数据集，关键词数量，具体模型（LSI、LDA），主题数量
    def __init__(self, doc_list, keyword_num, model='LSI', num_topics=4):
        # 使用gensim的接口，将文本转为向量化表示
        # 先构建词空间
        self.dictionary = corpora.Dictionary(doc_list)
        # 使用BOW模型向量化
        corpus = [self.dictionary.doc2bow(doc) for doc in doc_list]
        # 对每个词，根据tf-idf进行加权，得到加权后的向量表示
        self.tfidf_model = models.TfidfModel(corpus)
        self.corpus_tfidf = self.tfidf_model[corpus]

        self.keyword_num = keyword_num
        self.num_topics = num_topics
        # 选择加载的模型
        if model == 'LSI':
            self.model = self.train_lsi()
        else:
            self.model = self.train_lda()

        # 得到数据集的主题-词分布
        word_dic = self.word_dictionary(doc_list)
        self.wordtopic_dic = self.get_wordtopic(word_dic)

    def train_lsi(self):
        lsi = models.LsiModel(self.corpus_tfidf, id2word=self.dictionary, num_topics=self.num_topics)
        return lsi

    def train_lda(self):
        lda = models.LdaModel(self.corpus_tfidf, id2word=self.dictionary, num_topics=self.num_topics)
        return lda

    def get_wordtopic(self, word_dic):
        wordtopic_dic = {}

        for word in word_dic:
            single_list = [word]
            wordcorpus = self.tfidf_model[self.dictionary.doc2bow(single_list)]
            wordtopic = self.model[wordcorpus]
            wordtopic_dic[word] = wordtopic
        return wordtopic_dic

    # 计算词的分布和文档的分布的相似度，取相似度最高的keyword_num个词作为关键词
    def get_simword(self, word_list):
        sentcorpus = self.tfidf_model[self.dictionary.doc2bow(word_list)]
        senttopic = self.model[sentcorpus]

        # 余弦相似度计算
        def calsim(l1, l2):
            a, b, c = 0.0, 0.0, 0.0
            for t1, t2 in zip(l1, l2):
                x1 = t1[1]
                x2 = t2[1]
                a += x1 * x1
                b += x1 * x1
                c += x2 * x2
            sim = a / math.sqrt(b * c) if not (b * c) == 0.0 else 0.0
            return sim

        # 计算输入文本和每个词的主题分布相似度
        sim_dic = {}
        for k, v in self.wordtopic_dic.items():
            if k not in word_list:
                continue
            sim = calsim(v, senttopic)
            sim_dic[k] = sim

        for k, v in sorted(sim_dic.items(), key=functools.cmp_to_key(cmp), reverse=True)[:self.keyword_num]:
            file_number.write(k + ' ')
        file_number.write('\n')

    # 词空间构建方法和向量化方法，在没有gensim接口时的一般处理方法
    def word_dictionary(self, doc_list):
        dictionary = []
        for doc in doc_list:
            dictionary.extend(doc)

        dictionary = list(set(dictionary))

        return dictionary

    def doc2bowvec(self, word_list):
        vec_list = [1 if word in word_list else 0 for word in self.dictionary]
        return vec_list

def textrank_extract(text, keyword_num):
    textrank = analyse.textrank
    keywords = textrank(text, keyword_num)
    # 输出抽取出的关键词
    for keyword in keywords:
        file_number.write(keyword + ' ')
    file_number.write('\n')

def topic_extract(word_list, model, keyword_num):
    topic_model = TopicModel(word_list, keyword_num, model=model)
    for word in word_list:
        topic_model.get_simword(word)

def eachFile(filepath):
    pathDir =  os.listdir(filepath)
    dir_list=[]
    for allDir in pathDir:
        child = os.path.join('%s%s' % (filepath,allDir))
        dir_list.append(child)
    return dir_list

def keyword():
    path = 'F:/大三第二学期/自然语言处理/实验/实验语料/人民网-粤经济/'
    path_list = eachFile(path)
    doc_list = []
    doc1_list = []
    keyword_num = 5
    pos = True
    for di in path_list[:10]:  # 只选取10个文档
        filter_list = open(di, 'r', encoding='utf-8')
        book=filter_list.read()   #文档内容
        textrank_extract(book, keyword_num)
        filter1_list = load_data(book, pos=False)
        doc_list.append(filter1_list)
        filter2_list = load_data(book, pos)
        doc1_list.append(filter2_list)
    idf_dic, default_idf = train_idf(doc_list)
    TFIDF = TfIdf(idf_dic, default_idf, doc_list, keyword_num)
    TFIDF.get_tfidf()
    topic_extract(doc1_list, 'LSI', keyword_num)
    topic_extract(doc1_list, 'LDA', keyword_num)

def similarity(vector1,vector2):
    vector1Mod = np.sqrt(vector1.dot(vector1))
    vector2Mod = np.sqrt(vector2.dot(vector2))
    if vector2Mod != 0 and vector1Mod != 0:
        similarity = (vector1.dot(vector2)) / (vector1Mod * vector2Mod)
    else:
        similarity = 0
    return similarity

def word2vec():
    tf_file2 = open('number.txt', 'r', encoding='utf-8')
    model_path =r'E:\wiki\model\chinawikimodel.model'
    model = g.Word2Vec.load(model_path)
    wordvec_size=400

    list_1=[]
    for tf2 in tf_file2.readlines()[:40]:  #读取另一个文件前四十行，避免混淆
        word_vec_all = np.zeros(wordvec_size)  # 400维全为0的向量
        tflist=tf2.strip().split(' ')  #字符串根据空格分区
        first_word=tflist[0]   #每行选取权值最大的词语也就是第一个词语，如第一行的space_pos[0]=4
        if model.__contains__(first_word):  #如果模型中有这个词语的话
            word_vec_all=word_vec_all+model[first_word]  #全0向量加上模型中的相应词语向量
        else:
            for i in range(len(tflist)):  #范围是词语数
                word=tflist[i]
                if model.__contains__(word):
                    word_vec_all=word_vec_all+model[word]
        list_1.append(word_vec_all)

    texttf,textlsi,textlda,tflsi,tflda,lsilda=0,0,0,0,0,0
    for i_1,j_1 in enumerate(list_1): #40
        for i_2, j_2 in enumerate(list_1):  # 40
            if i_1<10:
                if (i_1+10)==i_2:  #0,10,20,30
                    texttf+=similarity(j_1,j_2)
                elif (i_1+20)==i_2:
                    textlsi+=similarity(j_1,j_2)
                elif (i_1+30)==i_2:
                    textlda+=similarity(j_1,j_2)
            if 10<=i_1 < 20:
                if (i_1 + 10) == i_2:  # 0,10,20,30
                    tflsi += similarity(j_1, j_2)
                elif (i_1 + 20) == i_2:
                    tflda += similarity(j_1, j_2)
            if 20<=i_1<30:
                if (i_1+10)==i_2:
                    lsilda+=similarity(j_1,j_2)

    texttf,textlsi,textlda,tflsi,tflda,lsilda=texttf/10,textlsi/10,textlda/10,tflsi/10,tflda/10,lsilda/10
    print(texttf,textlsi,textlda,tflsi,tflda,lsilda)

if __name__ == '__main__':
    file_number = open('number.txt', 'a', encoding='utf-8')
    # keyword()
    word2vec()

