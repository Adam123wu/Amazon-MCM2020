# -LSTM-
用LSTM进行文本的情感分析
用python3.6写的情感分析，代码我会尽可能详细的注释，供大家学习一下。
下载词向量后放在和py文件同一级的目录下就可以运行了。

在知乎上有理论和代码的讲解~
传送门：https://zhuanlan.zhihu.com/vortex
